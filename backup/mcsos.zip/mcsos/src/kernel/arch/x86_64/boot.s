	.section .text
	.global kmain
